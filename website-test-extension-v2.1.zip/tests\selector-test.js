/**
 * Test: getUniqueSelector logic
 * Kiểm tra thuật toán sinh CSS Selector duy nhất từ mock element
 */

function cssEscape(value) {
  return String(value).replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\$&");
}

/**
 * Phiên bản đơn giản hóa của getUniqueSelector dùng cho test (không cần DOM thật).
 * Logic phản ánh đúng thứ tự ưu tiên trong content-script.js:
 * 1. id nếu hợp lệ
 * 2. [data-testid], [data-test], [data-qa], [data-cy], [name]
 * 3. Fallback về tagName
 */
function getUniqueSelectorMock(element, allElements = []) {
  // 1. id
  if (element.id && /^[a-z_-]/i.test(element.id)) {
    const sel = `#${cssEscape(element.id)}`;
    const matches = allElements.filter(e => e.id === element.id);
    if (matches.length <= 1) return sel;
  }

  // 2. Data attributes
  for (const attr of ["data-testid", "data-test", "data-qa", "data-cy", "name"]) {
    const val = element.attrs?.[attr];
    if (val) {
      const sel = `${element.tag}[${attr}="${cssEscape(val)}"]`;
      const matches = allElements.filter(e => e.attrs?.[attr] === val);
      if (matches.length <= 1) return sel;
    }
  }

  // 3. Fallback
  return element.tag || "unknown";
}

const cases = [
  {
    name: "Unique id nên được dùng làm selector",
    element: { id: "submit-btn", tag: "button", attrs: {} },
    all: [{ id: "submit-btn", tag: "button", attrs: {} }],
    expected: "#submit-btn"
  },
  {
    name: "Id không unique (xuất hiện 2 lần) phải fallback",
    element: { id: "item", tag: "div", attrs: {} },
    all: [
      { id: "item", tag: "div", attrs: {} },
      { id: "item", tag: "div", attrs: {} }
    ],
    expected: "div"
  },
  {
    name: "data-testid unique nên được dùng",
    element: { id: "", tag: "button", attrs: { "data-testid": "checkout-btn" } },
    all: [{ id: "", tag: "button", attrs: { "data-testid": "checkout-btn" } }],
    expected: `button[data-testid="checkout-btn"]`
  },
  {
    name: "name attribute nên được dùng khi không có id",
    element: { id: "", tag: "input", attrs: { name: "email" } },
    all: [{ id: "", tag: "input", attrs: { name: "email" } }],
    expected: `input[name="email"]`
  },
  {
    name: "Không có id/data attr nên fallback về tag",
    element: { id: "", tag: "span", attrs: {} },
    all: [{ id: "", tag: "span", attrs: {} }],
    expected: "span"
  },
  {
    name: "Id bắt đầu bằng số không hợp lệ phải fallback",
    element: { id: "123invalid", tag: "div", attrs: {} },
    all: [{ id: "123invalid", tag: "div", attrs: {} }],
    expected: "div"
  }
];

let failed = 0;
cases.forEach(({ name, element, all, expected }) => {
  const actual = getUniqueSelectorMock(element, all);
  if (actual !== expected) {
    failed++;
    console.error(`FAIL: ${name}`, { expected, actual });
  }
});

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log(`Selector tests passed. (${cases.length} cases)`);
}
