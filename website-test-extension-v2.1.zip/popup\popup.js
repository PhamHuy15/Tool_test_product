const DEFAULT_CONFIG = {
  enabled: true,
  referenceUrl: "",
  siteType: "unknown",
  testScope: ["content", "ui", "responsive"],
  reportLanguage: "vi",
  maxPages: 30,
  crawlDelay: 800
};

const el = {
  enabledToggle:     document.getElementById("enabledToggle"),
  statusText:        document.getElementById("statusText"),
  currentUrl:        document.getElementById("currentUrl"),
  captureBtn:        document.getElementById("captureBtn"),
  crawlBtn:          document.getElementById("crawlBtn"),
  stopBtn:           document.getElementById("stopBtn"),
  copyBtn:           document.getElementById("copyBtn"),
  downloadBtn:       document.getElementById("downloadBtn"),
  summary:           document.getElementById("summary"),
  optionsBtn:        document.getElementById("optionsBtn"),
  scanLine:          document.getElementById("scanLine"),
  toast:             document.getElementById("toast"),
  progressContainer: document.getElementById("progressContainer"),
  progressText:      document.getElementById("progressText"),
  progressCount:     document.getElementById("progressCount"),
  progressBar:       document.getElementById("progressBar"),
  progressUrl:       document.getElementById("progressUrl")
};

let activeTab     = null;
let latestPackage = null;
let toastTimer    = null;
let isCrawling    = false;

// ── Init ────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", init);

async function init() {
  const stored = await chrome.storage.local.get(["enabled", "latestPackage"]);
  el.enabledToggle.checked = stored.enabled ?? DEFAULT_CONFIG.enabled;
  latestPackage = stored.latestPackage || null;
  updateStatus();
  await loadActiveTab();
  updateExportState();
  if (latestPackage) renderResult(latestPackage);

  // Lắng nghe progress từ service worker
  chrome.runtime.onMessage.addListener(onServiceWorkerMessage);
}

// ── Progress messages từ service worker ─────────────────────────────
function onServiceWorkerMessage(message) {
  if (message?.type !== "AI_TEST_CRAWLER_PROGRESS") return;
  const { phase, done = 0, total = 0, url = "" } = message;

  if (phase === "start") {
    showProgress(true);
    updateProgress("Đang khởi động crawler...", done, total, "");
  } else if (phase === "crawling") {
    updateProgress("Đang quét...", done, total, url);
  } else if (phase === "done" || phase === "stopped") {
    showProgress(false);
    setCrawlBusy(false);
    isCrawling = false;
    // Lấy package mới từ storage
    chrome.storage.local.get("latestPackage").then(({ latestPackage: pkg }) => {
      if (pkg) {
        latestPackage = pkg;
        renderResult(pkg);
        updateExportState();
      }
    });
    const msg = phase === "done"
      ? `✓ Hoàn tất! Đã quét ${total} trang.`
      : `⏹ Đã dừng sau ${done} trang.`;
    showToast(msg, "success");
  } else if (phase === "error") {
    showProgress(false);
    setCrawlBusy(false);
    isCrawling = false;
    showToast(`Lỗi crawl: ${message.message}`, "error");
  }
}

// ── Toggle ───────────────────────────────────────────────────────────
el.enabledToggle.addEventListener("change", async () => {
  await chrome.storage.local.set({ enabled: el.enabledToggle.checked });
  updateStatus();
});

// ── Single-page Capture ───────────────────────────────────────────────
el.captureBtn.addEventListener("click", async () => {
  if (!checkEnabled()) return;
  await loadActiveTab();
  if (!checkInjectableTab()) return;

  setSingleBusy(true);
  try {
    await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      files: ["content/content-script.js"]
    });

    const response = await chrome.tabs.sendMessage(activeTab.id, {
      type: "AI_TEST_COLLECTOR_CAPTURE"
    });
    if (!response?.ok) throw new Error(response?.error || "Content script không trả về dữ liệu.");

    const packageResponse = await chrome.runtime.sendMessage({
      type: "AI_TEST_COLLECTOR_BUILD_PACKAGE",
      targetUrl: activeTab.url,
      snapshot: response.snapshot
    });
    if (!packageResponse?.ok) throw new Error(packageResponse?.error || "Không tạo được JSON package.");

    latestPackage = packageResponse.package;
    renderResult(latestPackage);
    updateExportState();
    showToast("✓ Thu thập trang thành công!", "success");
  } catch (error) {
    showToast(`Lỗi: ${error.message}`, "error");
  } finally {
    setSingleBusy(false);
  }
});

// ── Full-site Crawl ───────────────────────────────────────────────────
el.crawlBtn.addEventListener("click", async () => {
  if (!checkEnabled()) return;
  await loadActiveTab();
  if (!checkInjectableTab()) return;
  if (isCrawling) return;

  // Trước tiên capture trang hiện tại để lấy seed links
  setSingleBusy(true);
  setCrawlBusy(true);
  isCrawling = true;
  showProgress(true);
  updateProgress("Đang lấy link từ trang gốc...", 0, 0, "");

  try {
    await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      files: ["content/content-script.js"]
    });
    const response = await chrome.tabs.sendMessage(activeTab.id, {
      type: "AI_TEST_COLLECTOR_CAPTURE"
    });

    const seedLinks = (response?.snapshot?.links || []).map(l => l.href).filter(Boolean);

    await chrome.runtime.sendMessage({
      type: "AI_TEST_COLLECTOR_CRAWL_SITE",
      originUrl: activeTab.url,
      seedLinks
    });
  } catch (error) {
    showProgress(false);
    setCrawlBusy(false);
    isCrawling = false;
    showToast(`Lỗi khởi động crawl: ${error.message}`, "error");
  } finally {
    setSingleBusy(false);
  }
});

// ── Stop Crawl ─────────────────────────────────────────────────────
el.stopBtn.addEventListener("click", async () => {
  try {
    await chrome.runtime.sendMessage({ type: "AI_TEST_COLLECTOR_STOP_CRAWL" });
    showToast("Đang dừng crawler...", "");
  } catch (err) {
    showToast(`Lỗi dừng: ${err.message}`, "error");
  }
});

// ── Copy ──────────────────────────────────────────────────────────
el.copyBtn.addEventListener("click", async () => {
  if (!latestPackage) return;
  try {
    await navigator.clipboard.writeText(JSON.stringify(latestPackage, null, 2));
    showToast("✓ Đã copy JSON vào clipboard", "success");
  } catch (error) {
    showToast(`Không copy được: ${error.message}`, "error");
  }
});

// ── Download ──────────────────────────────────────────────────────
el.downloadBtn.addEventListener("click", async () => {
  if (!latestPackage) return;
  try {
    const response = await chrome.runtime.sendMessage({
      type: "AI_TEST_COLLECTOR_DOWNLOAD_PACKAGE"
    });
    if (!response?.ok) throw new Error(response?.error || "Không tải được file.");
    showToast("✓ Đã lưu file JSON", "success");
  } catch (error) {
    showToast(`Lỗi tải file: ${error.message}`, "error");
  }
});

// ── Options ───────────────────────────────────────────────────────
el.optionsBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());

// ── Helpers ───────────────────────────────────────────────────────
async function loadActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tabs[0] || null;
  el.currentUrl.value = activeTab?.url || "Không lấy được URL.";
}

function checkEnabled() {
  if (!el.enabledToggle.checked) {
    showToast("Tool đang tắt — hãy bật toggle trước.", "error");
    return false;
  }
  return true;
}

function checkInjectableTab() {
  if (!activeTab || !activeTab.id || !isInjectableUrl(activeTab.url)) {
    showToast("Không thể chạy trên trang nội bộ Chrome.", "error");
    return false;
  }
  return true;
}

function updateStatus() {
  const on = el.enabledToggle.checked;
  el.statusText.textContent = on ? "Tool đang bật" : "Tool đang tắt";
  el.statusText.className   = "status-text " + (on ? "on" : "off");
}

function setSingleBusy(isBusy) {
  el.captureBtn.disabled = isBusy;
  el.captureBtn.classList.toggle("scanning", isBusy);
  el.scanLine.classList.toggle("active", isBusy);
}

function setCrawlBusy(isBusy) {
  el.crawlBtn.disabled = isBusy;
  el.crawlBtn.classList.toggle("scanning", isBusy);
  el.stopBtn.classList.toggle("hidden", !isBusy);
}

function showProgress(visible) {
  el.progressContainer.classList.toggle("hidden", !visible);
}

function updateProgress(text, done, total, url) {
  el.progressText.textContent  = text;
  el.progressCount.textContent = total > 0 ? `${done} / ${total}` : "";
  el.progressBar.style.width   = total > 0 ? `${Math.round((done / total) * 100)}%` : "0%";
  el.progressUrl.textContent   = url ? shortenUrl(url) : "";
}

function updateExportState() {
  const has = Boolean(latestPackage);
  el.copyBtn.disabled     = !has;
  el.downloadBtn.disabled = !has;
}

function showToast(message, type = "") {
  clearTimeout(toastTimer);
  el.toast.textContent = message;
  el.toast.className   = `toast${type ? " " + type : ""}`;
  el.toast.classList.add("visible");
  toastTimer = setTimeout(() => el.toast.classList.remove("visible"), 2800);
}

function isInjectableUrl(url) {
  return /^https?:\/\//i.test(url || "");
}

function shortenUrl(url) {
  try {
    const u = new URL(url);
    return u.pathname.length > 40 ? u.pathname.slice(0, 38) + "…" : u.pathname || "/";
  } catch {
    return url.slice(0, 40);
  }
}

// ── Render kết quả (single-page hoặc multi-page) ─────────────────
function renderResult(pkg) {
  if (!pkg) return;
  if (pkg.mode === "full-site-crawl") {
    renderSiteStats(pkg);
  } else {
    renderStats(pkg.pageSnapshot, pkg.targetUrl);
  }
}

/** Single-page stats grid */
function renderStats(snapshot, targetUrl) {
  if (!snapshot) return;
  const stats = [
    { label: "Headings",  value: snapshot.headings?.length  ?? 0 },
    { label: "Links",     value: snapshot.links?.length     ?? 0 },
    { label: "Buttons",   value: snapshot.buttons?.length   ?? 0 },
    { label: "Forms",     value: snapshot.forms?.length     ?? 0 },
    { label: "Products",  value: snapshot.products?.length  ?? 0 },
    { label: "Images",    value: snapshot.images?.length    ?? 0 }
  ];

  const meta  = snapshot.metadata  || {};
  const imgs  = snapshot.images    || [];
  const perf  = snapshot.performance || {};
  const missingAlt   = imgs.filter(i => i.hasMissingAlt).length;
  const undefinedAlt = imgs.filter(i => i.hasUndefinedAlt).length;

  el.summary.className = "summary has-data";
  el.summary.innerHTML = `
    <div class="stats-title">
      <span class="stats-title-dot"></span>
      ${escHtml(snapshot.title || "(không có tiêu đề)")}
    </div>
    <div class="stats-grid">
      ${stats.map(s => `
        <div class="stat-item">
          <span class="stat-value">${s.value}</span>
          <span class="stat-label">${escHtml(s.label)}</span>
        </div>`).join("")}
    </div>
    <div class="meta-row">
      ${buildSinglePills(meta, missingAlt, undefinedAlt, perf).join("")}
    </div>`;
}

/** Multi-page (site crawl) stats */
function renderSiteStats(pkg) {
  const s = pkg.summary || {};
  const stats = [
    { label: "Trang",    value: pkg.totalPages },
    { label: "Ảnh",      value: s.totalImages ?? 0 },
    { label: "No Alt",   value: s.imagesWithMissingAlt ?? 0 },
    { label: "Bad Alt",  value: s.imagesWithUndefinedAlt ?? 0 },
    { label: "No Canon", value: s.pagesWithoutCanonical ?? 0 },
    { label: "No Desc",  value: s.pagesWithoutMetaDesc ?? 0 }
  ];

  const slowPages = (s.slowPages || []).slice(0, 3);

  el.summary.className = "summary has-data";
  el.summary.innerHTML = `
    <div class="stats-title">
      <span class="stats-title-dot"></span>
      🌐 Full-site crawl — ${escHtml(pkg.domain || "")}
    </div>
    <div class="stats-grid">
      ${stats.map(s => `
        <div class="stat-item">
          <span class="stat-value" style="${s.value > 0 && s.label !== 'Trang' && s.label !== 'Ảnh' ? 'color:var(--clr-warn)' : ''}">${s.value}</span>
          <span class="stat-label">${escHtml(s.label)}</span>
        </div>`).join("")}
    </div>
    ${slowPages.length ? `
    <div class="meta-row">
      ${slowPages.map(p => `<span class="meta-pill warn">⏱ ${p.loadEventMs}ms — ${escHtml(shortenUrl(p.url))}</span>`).join("")}
    </div>` : ""}`;
}

function buildSinglePills(meta, missingAlt, undefinedAlt, perf) {
  const pills = [];
  if (meta.canonicalUrl) pills.push(`<span class="meta-pill ok">✓ Canonical</span>`);
  else                    pills.push(`<span class="meta-pill warn">⚠ No canonical</span>`);
  if (meta.description)  pills.push(`<span class="meta-pill ok">✓ Meta desc</span>`);
  else                    pills.push(`<span class="meta-pill warn">⚠ No meta desc</span>`);
  if (meta.ogTitle)       pills.push(`<span class="meta-pill ok">✓ OG Title</span>`);
  if (missingAlt > 0)     pills.push(`<span class="meta-pill warn">⚠ ${missingAlt} img no-alt</span>`);
  if (undefinedAlt > 0)   pills.push(`<span class="meta-pill warn">⚠ ${undefinedAlt} alt=undefined</span>`);
  if (perf.loadEventMs != null) {
    const cls = perf.loadEventMs < 2000 ? "ok" : "warn";
    pills.push(`<span class="meta-pill ${cls}">⏱ ${perf.loadEventMs}ms load</span>`);
  }
  return pills;
}

function escHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
