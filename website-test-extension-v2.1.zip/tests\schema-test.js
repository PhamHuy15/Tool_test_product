const expectedKeys = [
  "title",
  "headings",
  "links",
  "buttons",
  "forms",
  "visibleText",
  "products",
  "cartSignals"
];

function normalizeSnapshot(snapshot = {}) {
  return {
    title: String(snapshot.title || ""),
    headings: Array.isArray(snapshot.headings) ? snapshot.headings : [],
    links: Array.isArray(snapshot.links) ? snapshot.links : [],
    buttons: Array.isArray(snapshot.buttons) ? snapshot.buttons : [],
    forms: Array.isArray(snapshot.forms) ? snapshot.forms : [],
    visibleText: String(snapshot.visibleText || ""),
    products: Array.isArray(snapshot.products) ? snapshot.products : [],
    cartSignals: Array.isArray(snapshot.cartSignals) ? snapshot.cartSignals : []
  };
}

const snapshot = normalizeSnapshot({});
const actualKeys = Object.keys(snapshot);
let failed = 0;

if (JSON.stringify(actualKeys) !== JSON.stringify(expectedKeys)) {
  failed += 1;
  console.error("Schema key order mismatch", { expectedKeys, actualKeys });
}

for (const key of ["headings", "links", "buttons", "forms", "products", "cartSignals"]) {
  if (!Array.isArray(snapshot[key])) {
    failed += 1;
    console.error(`${key} must be an array fallback`);
  }
}

for (const key of ["title", "visibleText"]) {
  if (typeof snapshot[key] !== "string") {
    failed += 1;
    console.error(`${key} must be a string fallback`);
  }
}

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log("Schema tests passed.");
}
