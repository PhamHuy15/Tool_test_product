# AI Website Test Collector v2.0

AI Website Test Collector là Chrome Extension Manifest V3 dùng để thu thập dữ liệu an toàn từ website đang mở và xuất **JSON test package** cho AI Test local hoặc công cụ QA tự động.

Extension **không gọi API AI, không chạy kiểm thử thật, không gửi dữ liệu lên server.** Nó chỉ đọc cấu trúc và trạng thái hiển thị của trang khi người dùng chủ động bấm nút thu thập.

---

## ✨ Tính năng v2.0

### Thu thập dữ liệu nâng cao
- **CSS Selector**: Mỗi element (heading, link, button, form field, product, cart signal) đều có trường `selector` để AI Test có thể click/nhập liệu trực tiếp vào DOM.
- **Metadata & SEO**: Tự động trích xuất `meta[description]`, `meta[keywords]`, `og:title`, `og:description`, `og:image`, `twitter:title`, `canonical`, ngôn ngữ trang (`html[lang]`), và kích thước viewport.
- **Images & Accessibility**: Thu thập tối đa 50 ảnh hiển thị kèm `alt`, `title`, `aria-label`, kích thước DOM và flag `hasMissingAlt` / `hasUndefinedAlt`.
- **Performance**: Lưu `domContentLoadedMs`, `loadEventMs`, `ttfbMs`, `transferSizeKb` từ Navigation Timing API.

### Giao diện Sleek Dark Theme
- Dark Glassmorphism với neon accent (Electric Indigo + Royal Blue).
- **Stats Grid**: Hiển thị số liệu thu thập (Headings, Links, Buttons, Forms, Products, Images) ngay trong popup.
- **Meta Pills**: Badge cảnh báo tức thì về Missing Alt, Undefined Alt, thiếu Canonical, thiếu Meta Description, thời gian tải trang.
- **Micro-animations**: Scan-line, spinner, pulse-dot, toast notifications.
- **Options page** đồng bộ Dark Theme với custom checkbox scope-grid.

### Bảo mật không thay đổi
- Không đọc `value` của field nhạy cảm (password, card, cvv, otp, ssn).
- Chỉ dùng `activeTab` — chỉ có quyền trên tab hiện tại sau khi người dùng bấm nút.

---

## Cài đặt nhanh

1. Mở Chrome và vào `chrome://extensions`.
2. Bật **Developer mode**.
3. Chọn **Load unpacked**.
4. Chọn thư mục `website-test-extension`.
5. Ghim icon extension nếu muốn dùng thường xuyên.

---

## Schema JSON output (v2.0)

```json
{
  "targetUrl": "https://site-can-test.com",
  "referenceUrl": "https://site-mau.com",
  "siteType": "ecommerce",
  "testScope": ["content", "ui", "responsive", "accessibility"],
  "reportLanguage": "vi",
  "capturedAt": "ISO_DATETIME",
  "pageSnapshot": {
    "title": "Page Title",
    "headings": [
      { "level": "h1", "text": "Trang chủ", "selector": "#main-heading" }
    ],
    "links": [
      { "text": "Sản phẩm", "href": "https://...", "selector": "nav > a:nth-of-type(2)" }
    ],
    "buttons": [
      { "text": "Thêm vào giỏ", "disabled": false, "selector": "button[data-testid='add-to-cart']" }
    ],
    "forms": [
      {
        "index": 0,
        "action": "/search",
        "method": "get",
        "selector": "form#search-form",
        "fields": [
          {
            "tag": "input",
            "type": "search",
            "name": "q",
            "id": "search-input",
            "label": "Tìm kiếm",
            "placeholder": "Tìm sản phẩm...",
            "required": false,
            "sensitive": false,
            "selector": "#search-input"
          }
        ]
      }
    ],
    "visibleText": "...",
    "products": [
      {
        "name": "Áo khoác nam",
        "price": "₫299.000",
        "discount": "-30%",
        "image": "https://...",
        "link": "https://...",
        "selector": "article:nth-of-type(1)",
        "source": "heuristic"
      }
    ],
    "cartSignals": [
      { "text": "Giỏ hàng (2)", "href": "/cart", "itemCount": 2, "selector": "a#cart-icon" }
    ],
    "images": [
      {
        "src": "https://...",
        "alt": "Banner khuyến mãi",
        "title": "",
        "ariaLabel": "",
        "width": 1200,
        "height": 400,
        "hasMissingAlt": false,
        "hasUndefinedAlt": false,
        "selector": "img.hero-banner"
      }
    ],
    "metadata": {
      "lang": "vi",
      "description": "Mô tả trang...",
      "keywords": "",
      "ogTitle": "OG Title",
      "ogDescription": "OG Desc",
      "ogImage": "https://...",
      "twitterTitle": "",
      "canonicalUrl": "https://...",
      "viewport": {
        "width": 1440,
        "height": 900,
        "devicePixelRatio": 1,
        "scrollY": 0
      }
    },
    "performance": {
      "domContentLoadedMs": 850,
      "loadEventMs": 1200,
      "ttfbMs": 120,
      "transferSizeKb": 340
    }
  }
}
```

---

## Tests

```bash
node tests/schema-test.js
node tests/sensitive-field-test.js
node tests/product-and-label-test.js
node tests/forms-handling-test.js
node tests/admin-filter-test.js
node tests/selector-test.js
node tests/metadata-test.js
```

Tất cả 7 test suites đều có thể chạy bằng Node.js thuần (không cần framework).

---

## Ghi chú bảo mật

Extension dùng `activeTab`, nên chỉ có quyền trên tab hiện tại sau khi người dùng chủ động bấm icon/nút thu thập. Content script chỉ lấy cấu trúc form, selector và placeholder không nhạy cảm; nó **không lấy `value`** người dùng đã nhập trong form.
