const DEFAULT_CONFIG = {
  referenceUrl: "",
  siteType: "unknown",
  testScope: ["content", "ui", "responsive"],
  reportLanguage: "vi",
  maxPages: 30,
  crawlDelay: 800
};

// ── Trạng thái crawl (in-memory, reset mỗi lần crawl mới) ────────────
let crawlState = null; // { active, tabId, visited, queue, results, aborted }

// ── onInstalled: khởi tạo storage ───────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(["enabled", ...Object.keys(DEFAULT_CONFIG)]);
  const initialValues = {};
  if (typeof stored.enabled === "undefined") initialValues.enabled = true;
  for (const [key, value] of Object.entries(DEFAULT_CONFIG)) {
    if (typeof stored[key] === "undefined") initialValues[key] = value;
  }
  if (Object.keys(initialValues).length) {
    await chrome.storage.local.set(initialValues);
  }
});

// ── Message router ───────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

async function handleMessage(message) {
  // ── Single-page capture & build ─────────────────────────────────
  if (message?.type === "AI_TEST_COLLECTOR_BUILD_PACKAGE") {
    const config = await chrome.storage.local.get(Object.keys(DEFAULT_CONFIG));
    const testPackage = {
      mode: "single-page",
      targetUrl: message.targetUrl || "",
      referenceUrl: config.referenceUrl || "",
      siteType: config.siteType || DEFAULT_CONFIG.siteType,
      testScope: Array.isArray(config.testScope) ? config.testScope : DEFAULT_CONFIG.testScope,
      reportLanguage: config.reportLanguage || DEFAULT_CONFIG.reportLanguage,
      capturedAt: new Date().toISOString(),
      pageSnapshot: normalizeSnapshot(message.snapshot)
    };
    await chrome.storage.local.set({ latestPackage: testPackage });
    return { ok: true, package: testPackage };
  }

  // ── Download latest package ──────────────────────────────────────
  if (message?.type === "AI_TEST_COLLECTOR_DOWNLOAD_PACKAGE") {
    const { latestPackage } = await chrome.storage.local.get("latestPackage");
    if (!latestPackage) throw new Error("Chưa có JSON test package để tải.");
    const json = JSON.stringify(latestPackage, null, 2);
    const url = `data:application/json;charset=utf-8,${encodeURIComponent(json)}`;
    const filename = buildFilename(latestPackage);
    await chrome.downloads.download({ url, filename, saveAs: true });
    return { ok: true };
  }

  // ── Start full-site crawl ────────────────────────────────────────
  if (message?.type === "AI_TEST_COLLECTOR_CRAWL_SITE") {
    if (crawlState?.active) throw new Error("Đang có crawl đang chạy.");
    // Không await — crawl chạy nền, báo tiến độ qua sendProgressUpdate
    startCrawl(message.originUrl, message.seedLinks || []).catch((err) => {
      sendProgressUpdate({ phase: "error", message: err.message });
    });
    return { ok: true, started: true };
  }

  // ── Stop crawl ───────────────────────────────────────────────────
  if (message?.type === "AI_TEST_COLLECTOR_STOP_CRAWL") {
    if (crawlState) crawlState.aborted = true;
    return { ok: true };
  }

  return { ok: false, error: "Message không được hỗ trợ." };
}

// ── Full-site crawler ────────────────────────────────────────────────
async function startCrawl(originUrl, seedLinks) {
  const config = await chrome.storage.local.get(Object.keys(DEFAULT_CONFIG));
  const maxPages  = Number(config.maxPages)  || DEFAULT_CONFIG.maxPages;
  const delay     = Number(config.crawlDelay) || DEFAULT_CONFIG.crawlDelay;
  const origin    = getOrigin(originUrl);

  if (!origin) throw new Error("Không xác định được domain gốc.");

  // Khởi tạo state
  crawlState = {
    active:  true,
    aborted: false,
    visited: new Set(),
    queue:   [],
    results: []
  };

  // Seed queue: trang hiện tại + tất cả link nội bộ đã lấy được
  enqueueInternalLinks(crawlState, [originUrl, ...seedLinks], origin);

  sendProgressUpdate({ phase: "start", total: crawlState.queue.length, done: 0 });

  // Tạo 1 tab nền để dùng cho crawl
  const tab = await chrome.tabs.create({ url: "about:blank", active: false });
  crawlState.tabId = tab.id;

  try {
    while (crawlState.queue.length > 0 && !crawlState.aborted) {
      if (crawlState.visited.size >= maxPages) break;

      const url = crawlState.queue.shift();
      if (crawlState.visited.has(url)) continue;
      crawlState.visited.add(url);

      const done = crawlState.visited.size;
      const total = Math.min(crawlState.visited.size + crawlState.queue.length, maxPages);
      sendProgressUpdate({ phase: "crawling", url, done, total });

      try {
        const { snapshot, newLinks } = await captureTabUrl(crawlState.tabId, url, delay);
        crawlState.results.push({ url, crawledAt: new Date().toISOString(), pageSnapshot: normalizeSnapshot(snapshot) });
        // Thêm các link mới tìm được vào queue
        enqueueInternalLinks(crawlState, newLinks, origin);
      } catch (err) {
        crawlState.results.push({ url, crawledAt: new Date().toISOString(), error: err.message, pageSnapshot: normalizeSnapshot({}) });
      }
    }
  } finally {
    // Đóng tab nền
    try { await chrome.tabs.remove(crawlState.tabId); } catch {}
    crawlState.active = false;
  }

  // Tạo multi-page package
  const sitePackage = buildSitePackage(originUrl, origin, config, crawlState.results);
  await chrome.storage.local.set({ latestPackage: sitePackage });

  const aborted = crawlState.aborted;
  crawlState = null;

  sendProgressUpdate({
    phase: aborted ? "stopped" : "done",
    total: sitePackage.totalPages,
    done:  sitePackage.totalPages
  });
}

/**
 * Điều hướng tab đến url, chờ load xong, inject script và capture.
 * Trả về { snapshot, newLinks[] }
 */
async function captureTabUrl(tabId, url, delay) {
  await chrome.tabs.update(tabId, { url });
  await waitForTabLoad(tabId);
  await sleep(delay); // Chờ thêm để SPA render

  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content/content-script.js"]
  });

  // Reset flag đăng ký (để script inject lại được nếu cần)
  await chrome.scripting.executeScript({
    target: { tabId },
    func: () => { window.__aiWebsiteTestCollectorRegistered = false; }
  });

  const response = await chrome.tabs.sendMessage(tabId, { type: "AI_TEST_COLLECTOR_CAPTURE" });
  if (!response?.ok) throw new Error(response?.error || "Không capture được trang.");

  // Lấy luôn các link nội bộ từ trang vừa capture
  const newLinks = (response.snapshot?.links || [])
    .map(l => l.href || "")
    .filter(Boolean);

  return { snapshot: response.snapshot, newLinks };
}

/** Chờ tab load xong (status === 'complete') */
function waitForTabLoad(tabId, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(); // timeout → vẫn thử capture
    }, timeoutMs);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

/** Thêm các URL hợp lệ cùng domain vào queue (không trùng lặp) */
function enqueueInternalLinks(state, links, origin) {
  for (const href of links) {
    const normalized = normalizeUrl(href, origin);
    if (normalized && !state.visited.has(normalized) && !state.queue.includes(normalized)) {
      state.queue.push(normalized);
    }
  }
}

/** Normalize URL: bỏ fragment, chỉ giữ cùng origin */
function normalizeUrl(href, origin) {
  if (!href) return null;
  try {
    const url = new URL(href);
    if (url.origin !== origin) return null;
    // Bỏ qua file/download/mail/tel
    if (/\.(pdf|zip|docx?|xlsx?|png|jpe?g|gif|svg|webp|mp4|mp3)$/i.test(url.pathname)) return null;
    url.hash = ""; // Bỏ fragment
    return url.href;
  } catch {
    return null;
  }
}

function getOrigin(url) {
  try { return new URL(url).origin; } catch { return null; }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/** Gửi progress update về tất cả popup đang mở */
function sendProgressUpdate(data) {
  chrome.runtime.sendMessage({ type: "AI_TEST_CRAWLER_PROGRESS", ...data }).catch(() => {});
}

// ── Build site package (multi-page) ─────────────────────────────────
function buildSitePackage(originUrl, domain, config, pages) {
  const summary = buildSiteSummary(pages);
  return {
    mode: "full-site-crawl",
    domain,
    originUrl,
    crawledAt: new Date().toISOString(),
    totalPages: pages.length,
    config: {
      siteType:       config.siteType || DEFAULT_CONFIG.siteType,
      testScope:      Array.isArray(config.testScope) ? config.testScope : DEFAULT_CONFIG.testScope,
      reportLanguage: config.reportLanguage || DEFAULT_CONFIG.reportLanguage,
      referenceUrl:   config.referenceUrl || ""
    },
    summary,
    pages
  };
}

function buildSiteSummary(pages) {
  let totalImages = 0;
  let imagesWithMissingAlt = 0;
  let imagesWithUndefinedAlt = 0;
  let pagesWithoutCanonical = 0;
  let pagesWithoutMetaDesc = 0;
  const slowPages = [];
  const errors = [];

  for (const page of pages) {
    if (page.error) { errors.push({ url: page.url, error: page.error }); continue; }
    const snap = page.pageSnapshot || {};
    const imgs = snap.images || [];
    const meta = snap.metadata || {};
    const perf = snap.performance || {};

    totalImages           += imgs.length;
    imagesWithMissingAlt  += imgs.filter(i => i.hasMissingAlt).length;
    imagesWithUndefinedAlt += imgs.filter(i => i.hasUndefinedAlt).length;
    if (!meta.canonicalUrl)  pagesWithoutCanonical++;
    if (!meta.description)   pagesWithoutMetaDesc++;
    if (perf.loadEventMs > 3000) {
      slowPages.push({ url: page.url, loadEventMs: perf.loadEventMs });
    }
  }

  slowPages.sort((a, b) => b.loadEventMs - a.loadEventMs);

  return {
    totalImages,
    imagesWithMissingAlt,
    imagesWithUndefinedAlt,
    pagesWithoutCanonical,
    pagesWithoutMetaDesc,
    slowPages: slowPages.slice(0, 10),
    crawlErrors: errors
  };
}

// ── Single-page helpers ──────────────────────────────────────────────
function normalizeSnapshot(snapshot = {}) {
  return {
    title:       String(snapshot.title || ""),
    headings:    Array.isArray(snapshot.headings)    ? snapshot.headings    : [],
    links:       Array.isArray(snapshot.links)       ? snapshot.links       : [],
    buttons:     Array.isArray(snapshot.buttons)     ? snapshot.buttons     : [],
    forms:       Array.isArray(snapshot.forms)       ? snapshot.forms       : [],
    visibleText: String(snapshot.visibleText || ""),
    products:    Array.isArray(snapshot.products)    ? snapshot.products    : [],
    cartSignals: Array.isArray(snapshot.cartSignals) ? snapshot.cartSignals : [],
    images:      Array.isArray(snapshot.images)      ? snapshot.images      : [],
    metadata:    (snapshot.metadata   && typeof snapshot.metadata   === "object") ? snapshot.metadata   : {},
    performance: (snapshot.performance && typeof snapshot.performance === "object") ? snapshot.performance : {}
  };
}

function buildFilename(pkg) {
  const isCrawl = pkg.mode === "full-site-crawl";
  let host = "website";
  try {
    const url = isCrawl ? pkg.domain : (pkg.targetUrl || "");
    host = new URL(url).hostname.replace(/[^a-z0-9.-]/gi, "-");
  } catch {}
  const prefix = isCrawl ? "ai-site-crawl" : "ai-test-package";
  return `${prefix}-${host}-${Date.now()}.json`;
}
