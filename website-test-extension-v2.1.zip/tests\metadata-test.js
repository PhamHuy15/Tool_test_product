/**
 * Test: collectMetadata logic
 * Kiểm tra tính chính xác của dữ liệu metadata/SEO trả về
 */

/**
 * Mock version of collectMetadata dùng một đối tượng head meta giả.
 */
function collectMetadataMock(headMeta = {}, htmlLang = "", windowDims = {}) {
  const getMeta = (key) => headMeta[key] || "";

  return {
    lang: htmlLang,
    description: getMeta("meta[name='description']"),
    keywords: getMeta("meta[name='keywords']"),
    ogTitle: getMeta("meta[property='og:title']"),
    ogDescription: getMeta("meta[property='og:description']"),
    ogImage: getMeta("meta[property='og:image']"),
    twitterTitle: getMeta("meta[name='twitter:title']"),
    canonicalUrl: getMeta("link[rel='canonical']"),
    viewport: {
      width:            windowDims.width || 0,
      height:           windowDims.height || 0,
      devicePixelRatio: windowDims.dpr || 1,
      scrollY:          windowDims.scrollY || 0
    }
  };
}

const cases = [
  {
    name: "Có đầy đủ meta description và canonical",
    head: {
      "meta[name='description']": "Trang chủ KFC Việt Nam",
      "link[rel='canonical']":    "https://www.kfcvietnam.com.vn/"
    },
    lang:  "vi",
    dims:  { width: 1440, height: 900, dpr: 1, scrollY: 0 },
    check: (result) => {
      if (result.description !== "Trang chủ KFC Việt Nam") return "description mismatch";
      if (result.canonicalUrl !== "https://www.kfcvietnam.com.vn/") return "canonical mismatch";
      if (result.lang !== "vi") return "lang mismatch";
      if (result.viewport.width !== 1440) return "viewport.width mismatch";
      return null;
    }
  },
  {
    name: "Thiếu meta description trả về chuỗi rỗng",
    head: {},
    lang:  "en",
    dims:  {},
    check: (result) => {
      if (result.description !== "") return "description phải là rỗng";
      if (result.canonicalUrl !== "") return "canonical phải là rỗng";
      return null;
    }
  },
  {
    name: "og:title và og:description được thu thập đúng",
    head: {
      "meta[property='og:title']":       "KFC Vietnam",
      "meta[property='og:description']": "Gà rán giòn ngon"
    },
    lang:  "",
    dims:  {},
    check: (result) => {
      if (result.ogTitle !== "KFC Vietnam") return "ogTitle mismatch";
      if (result.ogDescription !== "Gà rán giòn ngon") return "ogDescription mismatch";
      return null;
    }
  },
  {
    name: "Viewport dimensions được lưu chính xác",
    head: {},
    lang:  "",
    dims:  { width: 375, height: 812, dpr: 3, scrollY: 200 },
    check: (result) => {
      if (result.viewport.width  !== 375) return "width mismatch";
      if (result.viewport.height !== 812) return "height mismatch";
      if (result.viewport.devicePixelRatio !== 3) return "dpr mismatch";
      if (result.viewport.scrollY !== 200) return "scrollY mismatch";
      return null;
    }
  },
  {
    name: "Twitter title được thu thập đúng",
    head: { "meta[name='twitter:title']": "KFC Twitter" },
    lang: "",
    dims: {},
    check: (result) => result.twitterTitle !== "KFC Twitter" ? "twitterTitle mismatch" : null
  }
];

let failed = 0;
cases.forEach(({ name, head, lang, dims, check }) => {
  const result = collectMetadataMock(head, lang, dims);
  const err    = check(result);
  if (err) {
    failed++;
    console.error(`FAIL: ${name} — ${err}`, result);
  }
});

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log(`Metadata tests passed. (${cases.length} cases)`);
}
