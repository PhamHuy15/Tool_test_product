# Hướng Dẫn Cài Đặt AI Website Test Collector

Tài liệu này dành cho người không rành kỹ thuật. Bạn chỉ cần làm theo từng bước bên dưới.

## 1. Giải nén file extension

1. Tải file `website-test-extension-v1.0.zip` về máy.
2. Bấm chuột phải vào file `.zip`.
3. Chọn `Extract All...` hoặc `Giải nén tất cả`.
4. Sau khi giải nén, bạn sẽ thấy thư mục `website-test-extension`.

## 2. Mở trang quản lý extension của Chrome

1. Mở trình duyệt Google Chrome.
2. Gõ `chrome://extensions` vào thanh địa chỉ.
3. Nhấn Enter.

## 3. Bật Developer mode

1. Nhìn góc trên bên phải trang `chrome://extensions`.
2. Bật công tắc `Developer mode`.

## 4. Load extension vào Chrome

1. Bấm nút `Load unpacked`.
2. Chọn đúng thư mục `website-test-extension` vừa giải nén.
3. Bấm `Select Folder`.
4. Nếu thấy extension `AI Website Test Collector` xuất hiện, bạn đã cài đặt thành công.

## 5. Ghim icon extension

1. Bấm biểu tượng mảnh ghép trên thanh công cụ Chrome.
2. Tìm `AI Website Test Collector`.
3. Bấm biểu tượng ghim để extension luôn hiện trên thanh công cụ.

## 6. Cách sử dụng cơ bản

1. Mở website bạn muốn kiểm tra.
2. Bấm icon `AI Website Test Collector`.
3. Nếu tool đang tắt, bật công tắc ở góc trên popup.
4. Bấm `Thu thập dữ liệu trang này`.
5. Đợi popup hiện tóm tắt dữ liệu đã lấy.
6. Bấm `Copy JSON` để copy dữ liệu, hoặc bấm `Tải JSON` để tải file `.json`.
7. Dùng JSON này ở bước kiểm thử sau với prompt Codex riêng.

## 7. Cấu hình website mẫu

1. Trong popup, bấm `Mở cấu hình`.
2. Nhập URL website mẫu vào ô `URL website mẫu để đối chiếu`.
3. Chọn loại website, ví dụ `ecommerce`, `landing`, `blog`, `webapp` hoặc `unknown`.
4. Chọn phạm vi test cần dùng.
5. Chọn ngôn ngữ báo cáo.
6. Bấm `Lưu cấu hình`.

## 8. Lưu ý thường gặp

- Extension không chạy trên các trang nội bộ như `chrome://extensions`, `chrome://settings` hoặc Chrome Web Store. Đây là giới hạn bình thường của Chrome.
- Vì đây là extension tự build và load thủ công, Chrome có thể hiện cảnh báo `Disable developer mode extensions` khi mở trình duyệt. Đây là cảnh báo bình thường, không phải lỗi.
- Extension không tự chạy AI và không tự test website. Nó chỉ tạo JSON test package để đưa sang Codex kiểm thử ở bước sau.
- Extension không gửi dữ liệu website lên server.
