const DEFAULT_CONFIG = {
  referenceUrl: "",
  siteType: "unknown",
  testScope: ["content", "ui", "responsive"],
  reportLanguage: "vi",
  maxPages: 30,
  crawlDelay: 800
};

const form           = document.getElementById("optionsForm");
const referenceUrlEl = document.getElementById("referenceUrl");
const siteTypeEl     = document.getElementById("siteType");
const reportLangEl   = document.getElementById("reportLanguage");
const maxPagesEl     = document.getElementById("maxPages");
const crawlDelayEl   = document.getElementById("crawlDelay");
const messageEl      = document.getElementById("message");

document.addEventListener("DOMContentLoaded", loadOptions);
form.addEventListener("submit", saveOptions);

async function loadOptions() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULT_CONFIG));
  const config = { ...DEFAULT_CONFIG, ...stored };

  referenceUrlEl.value = config.referenceUrl || "";
  siteTypeEl.value     = config.siteType;
  reportLangEl.value   = config.reportLanguage;
  maxPagesEl.value     = config.maxPages;
  crawlDelayEl.value   = config.crawlDelay;

  document.querySelectorAll('input[name="testScope"]').forEach((cb) => {
    cb.checked = config.testScope.includes(cb.value);
  });
}

async function saveOptions(event) {
  event.preventDefault();
  messageEl.textContent = "";
  messageEl.className   = "save-message";

  const cleanUrl = referenceUrlEl.value.trim();
  if (cleanUrl && !isValidHttpUrl(cleanUrl)) {
    showMessage("URL không hợp lệ. Cần bắt đầu bằng http:// hoặc https://", "error");
    return;
  }

  const maxPages   = Math.max(1, Math.min(200, Number(maxPagesEl.value)  || DEFAULT_CONFIG.maxPages));
  const crawlDelay = Math.max(200, Math.min(5000, Number(crawlDelayEl.value) || DEFAULT_CONFIG.crawlDelay));

  const selectedScope = Array.from(
    document.querySelectorAll('input[name="testScope"]:checked')
  ).map((cb) => cb.value);

  await chrome.storage.local.set({
    referenceUrl:   cleanUrl,
    siteType:       siteTypeEl.value,
    testScope:      selectedScope,
    reportLanguage: reportLangEl.value,
    maxPages,
    crawlDelay
  });

  showMessage("✓ Đã lưu cấu hình", "success");
}

function showMessage(text, type) {
  messageEl.textContent = text;
  messageEl.className   = `save-message ${type}`;
  // Tự xóa sau 3 giây
  setTimeout(() => {
    if (messageEl.textContent === text) {
      messageEl.textContent = "";
      messageEl.className   = "save-message";
    }
  }, 3000);
}

function isValidHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}
