function cleanText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function extractPrice(text) {
  const pricePattern = /(?:₫|đ|vnd)\s?\d[\d.,\s]*|(?:\d[\d.,\s]*)\s?(?:₫|đ|vnd)|(?:\$|€|£)\s?\d[\d.,\s]*|(?:\d[\d.,\s]*)\s?(?:\$|€|£)/i;
  return cleanText((String(text || "").match(pricePattern) || [""])[0]);
}

function extractDiscount(text) {
  const discountPattern = /-?\d{1,2}\s?%/;
  return cleanText((String(text || "").match(discountPattern) || [""])[0]);
}

function guessProductNameFromLink(link, imageAlt, text, price) {
  if (imageAlt) return imageAlt;

  const parts = text
    .split(/\n| {2,}/)
    .map(cleanText)
    .filter(Boolean)
    .filter((part) => part !== price && !extractPrice(part) && !/^-?\d{1,2}\s?%$/.test(part));

  return parts[0] || cleanText(link.title || link.ariaLabel || "");
}

function findFieldLabelFromTrustedSources(field, directLabelText = "") {
  if (field.id && directLabelText) return cleanText(directLabelText);
  return cleanText(field.ariaLabel || "");
}

const productText = "Áo khoác flash sale\n-45%\n₫129.000\nĐã bán 2,1k";
const price = extractPrice(productText);
const productName = guessProductNameFromLink({}, "Áo khoác nam chống nắng", productText, price);

const cases = [
  ["extract VND price", price, "₫129.000"],
  ["extract discount", extractDiscount(productText), "-45%"],
  ["prefer image alt as product name", productName, "Áo khoác nam chống nắng"],
  ["fallback to aria label", findFieldLabelFromTrustedSources({ ariaLabel: "Tìm kiếm" }), "Tìm kiếm"],
  ["do not use placeholder as label", findFieldLabelFromTrustedSources({ placeholder: "Nhập từ khóa" }), ""],
  ["do not use unrelated wrapper/banner text", findFieldLabelFromTrustedSources({}, "S REWARDS tặng 1 năm ShopeeVIP"), ""]
];

let failed = 0;
cases.forEach(([name, actual, expected]) => {
  if (actual !== expected) {
    failed += 1;
    console.error(`Case failed: ${name}`, { expected, actual });
  }
});

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log("Product and label tests passed.");
}
