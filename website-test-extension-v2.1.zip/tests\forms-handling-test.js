function cleanText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function createField(attrs = {}) {
  return {
    tagName: attrs.tagName || "INPUT",
    disabled: Boolean(attrs.disabled),
    required: Boolean(attrs.required),
    visible: attrs.visible !== false,
    attributes: attrs,
    hasAttribute(name) {
      return Object.prototype.hasOwnProperty.call(this.attributes, name);
    },
    getAttribute(name) {
      return this.attributes[name] || "";
    }
  };
}

function isSafelyVisible(field) {
  return Boolean(field.visible);
}

function isCollectableFormField(field) {
  if (!isSafelyVisible(field)) return false;

  const tag = field.tagName.toLowerCase();
  const type = (field.getAttribute("type") || "").toLowerCase();
  if (tag === "input" && ["hidden", "button", "submit", "reset", "image"].includes(type)) return false;
  if (field.disabled) return false;
  if (field.getAttribute("aria-hidden") === "true") return false;

  return true;
}

function getTrustedFieldText(field, attributeName) {
  if (!field.hasAttribute(attributeName)) return "";
  return cleanText(field.getAttribute(attributeName) || "");
}

function isLikelyPromotionalFieldText(text) {
  return /s\s*rewards|shopeevip/i.test(text || "");
}

function getTrustedPlaceholder(field) {
  const placeholder = getTrustedFieldText(field, "placeholder");
  if (isLikelyPromotionalFieldText(placeholder)) return "";
  return placeholder;
}

function getTrustedLabelText(labelText) {
  const cleaned = cleanText(labelText);
  if (isLikelyPromotionalFieldText(cleaned)) return "";
  return cleaned;
}

function findFieldLabel(field, directLabelText = "") {
  if (field.getAttribute("id") && directLabelText) {
    const trustedDirectLabel = getTrustedLabelText(directLabelText);
    if (trustedDirectLabel) return trustedDirectLabel;
  }

  const ariaLabel = getTrustedFieldText(field, "aria-label");
  if (isLikelyPromotionalFieldText(ariaLabel)) return "";
  return ariaLabel;
}

function fieldToSafeStructure(field, directLabelText = "") {
  return {
    label: findFieldLabel(field, directLabelText),
    placeholder: getTrustedPlaceholder(field)
  };
}

const adText = "S REWARDS tặng 1 năm ShopeeVIP";
const cases = [
  {
    name: "visible input without own label or placeholder ignores nearby ad text",
    field: createField({ type: "text" }),
    directLabelText: "",
    expectedCollectable: true,
    expectedLabel: "",
    expectedPlaceholder: ""
  },
  {
    name: "hidden ad carrier field is not collected",
    field: createField({ type: "hidden", placeholder: adText }),
    directLabelText: "",
    expectedCollectable: false
  },
  {
    name: "trusted placeholder from the input itself is kept as placeholder only",
    field: createField({ type: "search", placeholder: "Tìm sản phẩm" }),
    directLabelText: "",
    expectedCollectable: true,
    expectedLabel: "",
    expectedPlaceholder: "Tìm sản phẩm"
  },
  {
    name: "promotional Shopee placeholder is not used as label or placeholder",
    field: createField({ type: "search", placeholder: adText }),
    directLabelText: "",
    expectedCollectable: true,
    expectedLabel: "",
    expectedPlaceholder: ""
  },
  {
    name: "trusted label for matching id is kept",
    field: createField({ type: "text", id: "email" }),
    directLabelText: "Email",
    expectedCollectable: true,
    expectedLabel: "Email",
    expectedPlaceholder: ""
  },
  {
    name: "promotional direct label for matching id is rejected",
    field: createField({ type: "text", id: "promo-search" }),
    directLabelText: adText,
    expectedCollectable: true,
    expectedLabel: "",
    expectedPlaceholder: ""
  },
  {
    name: "promotional aria label is rejected",
    field: createField({ type: "search", "aria-label": adText }),
    directLabelText: "",
    expectedCollectable: true,
    expectedLabel: "",
    expectedPlaceholder: ""
  }
];

let failed = 0;
cases.forEach((testCase) => {
  const collectable = isCollectableFormField(testCase.field);
  if (collectable !== testCase.expectedCollectable) {
    failed += 1;
    console.error(`Collectable mismatch: ${testCase.name}`, { expected: testCase.expectedCollectable, actual: collectable });
    return;
  }

  if (!collectable) return;
  const structure = fieldToSafeStructure(testCase.field, testCase.directLabelText);
  if (structure.label !== testCase.expectedLabel || structure.placeholder !== testCase.expectedPlaceholder) {
    failed += 1;
    console.error(`Structure mismatch: ${testCase.name}`, { expected: testCase, actual: structure });
  }
});

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log("Forms handling tests passed.");
}
