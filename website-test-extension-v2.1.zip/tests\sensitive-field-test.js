const sensitiveWords = ["password", "card", "cvv", "cvc", "otp", "ssn"];
const cardAutocomplete = ["cc-number", "cc-csc", "cc-exp", "cc-exp-month", "cc-exp-year", "cc-name"];

function isSensitiveFieldLike(field) {
  const type = (field.type || "").toLowerCase();
  const autocomplete = (field.autocomplete || "").toLowerCase();
  const haystack = [
    field.name || "",
    field.id || "",
    field.ariaLabel || "",
    autocomplete
  ].join(" ").toLowerCase();

  return type === "password" ||
    cardAutocomplete.some((word) => autocomplete.includes(word)) ||
    sensitiveWords.some((word) => haystack.includes(word));
}

const cases = [
  [{ type: "password" }, true],
  [{ name: "credit_card_number" }, true],
  [{ id: "otp-code" }, true],
  [{ autocomplete: "cc-csc" }, true],
  [{ name: "search", type: "search" }, false],
  [{ name: "email", type: "email" }, false]
];

let failed = 0;
cases.forEach(([input, expected], index) => {
  const actual = isSensitiveFieldLike(input);
  if (actual !== expected) {
    failed += 1;
    console.error(`Case ${index + 1} failed`, { input, expected, actual });
  }
});

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log("Sensitive field tests passed.");
}
