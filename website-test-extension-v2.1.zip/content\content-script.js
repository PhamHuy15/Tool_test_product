(function registerCollector() {
  if (window.__aiWebsiteTestCollectorRegistered) return;
  window.__aiWebsiteTestCollectorRegistered = true;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== "AI_TEST_COLLECTOR_CAPTURE") return false;

    capturePage()
      .then((snapshot) => sendResponse({ ok: true, snapshot }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));

    return true;
  });
})();

async function capturePage() {
  await waitForStableDom();

  return {
    title: document.title || "",
    headings: collectArraySafely("headings", collectHeadings),
    links: collectArraySafely("links", collectLinks),
    buttons: collectArraySafely("buttons", collectButtons),
    forms: collectArraySafely("forms", collectForms),
    visibleText: collectStringSafely("visibleText", collectVisibleText),
    products: collectArraySafely("products", collectProducts),
    cartSignals: collectArraySafely("cartSignals", collectCartSignals),
    images: collectArraySafely("images", collectImages),
    metadata: collectObjectSafely("metadata", collectMetadata),
    performance: collectObjectSafely("performance", collectPerformance)
  };
}

function collectArraySafely(name, collector) {
  try {
    const value = collector();
    return Array.isArray(value) ? value : [];
  } catch (error) {
    console.warn(`[AI Website Test Collector] ${name} collector failed:`, error);
    return [];
  }
}

function collectStringSafely(name, collector) {
  try {
    const value = collector();
    return typeof value === "string" ? value : "";
  } catch (error) {
    console.warn(`[AI Website Test Collector] ${name} collector failed:`, error);
    return "";
  }
}

function collectObjectSafely(name, collector) {
  try {
    const value = collector();
    return (value && typeof value === "object" && !Array.isArray(value)) ? value : {};
  } catch (error) {
    console.warn(`[AI Website Test Collector] ${name} collector failed:`, error);
    return {};
  }
}

function waitForStableDom({ quietMs = 500, maxWaitMs = 5000 } = {}) {
  return new Promise((resolve) => {
    let settled = false;
    let quietTimer = null;

    const finish = () => {
      if (settled) return;
      settled = true;
      observer.disconnect();
      clearTimeout(quietTimer);
      resolve();
    };

    const observer = new MutationObserver(() => {
      clearTimeout(quietTimer);
      quietTimer = setTimeout(finish, quietMs);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true
    });

    quietTimer = setTimeout(finish, quietMs);
    setTimeout(finish, maxWaitMs);
  });
}

// ─── CSS SELECTOR GENERATOR ────────────────────────────────────────────────
/**
 * Trả về CSS selector ngắn nhất có thể định vị duy nhất element trên trang.
 * Ưu tiên: id > [data-testid] > nth-child path
 */
function getUniqueSelector(element) {
  if (!element || !(element instanceof Element)) return "";
  try {
    if (element.id && /^[a-z_-]/i.test(element.id)) {
      const sel = `#${CSS.escape(element.id)}`;
      if (document.querySelectorAll(sel).length === 1) return sel;
    }

    for (const attr of ["data-testid", "data-test", "data-qa", "data-cy", "name"]) {
      const val = element.getAttribute(attr);
      if (val) {
        const sel = `${element.tagName.toLowerCase()}[${attr}="${CSS.escape(val)}"]`;
        if (document.querySelectorAll(sel).length === 1) return sel;
      }
    }

    const path = [];
    let current = element;
    while (current && current !== document.body && current !== document.documentElement) {
      const tag = current.tagName.toLowerCase();
      const siblings = current.parentElement
        ? Array.from(current.parentElement.children).filter(c => c.tagName === current.tagName)
        : [];
      const selectorPart = siblings.length > 1
        ? `${tag}:nth-of-type(${siblings.indexOf(current) + 1})`
        : tag;
      path.unshift(selectorPart);
      current = current.parentElement;
    }
    return path.length ? path.join(" > ") : element.tagName.toLowerCase();
  } catch {
    return element.tagName ? element.tagName.toLowerCase() : "";
  }
}

// ─── HEADINGS ─────────────────────────────────────────────────────────────
function collectHeadings() {
  return Array.from(document.querySelectorAll("h1, h2, h3"))
    .filter(isSafelyVisible)
    .slice(0, 80)
    .map((element) => ({
      level: element.tagName.toLowerCase(),
      text: cleanText(element.innerText || element.textContent),
      selector: getUniqueSelector(element)
    }))
    .filter((item) => item.text);
}

// ─── LINKS ────────────────────────────────────────────────────────────────
function collectLinks() {
  return Array.from(document.querySelectorAll("a[href]"))
    .filter(isSafelyVisible)
    .slice(0, 100)
    .map((element) => ({
      text: cleanText(element.innerText || element.textContent),
      href: element.href,
      selector: getUniqueSelector(element)
    }))
    .filter((item) => item.href);
}

// ─── BUTTONS ──────────────────────────────────────────────────────────────
function collectButtons() {
  return Array.from(document.querySelectorAll("button, input[type='button'], input[type='submit'], [role='button']"))
    .filter(isSafelyVisible)
    .slice(0, 100)
    .map((element) => ({
      text: cleanText(element.innerText || element.value || element.getAttribute("aria-label") || element.textContent),
      disabled: Boolean(element.disabled || element.getAttribute("aria-disabled") === "true"),
      selector: getUniqueSelector(element)
    }))
    .filter((item) => item.text);
}

// ─── FORMS ────────────────────────────────────────────────────────────────
function collectForms() {
  return Array.from(document.querySelectorAll("form"))
    .filter(isSafelyVisible)
    .slice(0, 30)
    .map((form, formIndex) => ({
      index: formIndex,
      action: form.getAttribute("action") || "",
      method: (form.getAttribute("method") || "get").toLowerCase(),
      selector: getUniqueSelector(form),
      fields: Array.from(form.querySelectorAll("input, textarea, select"))
        .filter(isCollectableFormField)
        .slice(0, 80)
        .map((field) => fieldToSafeStructure(field))
    }));
}

function fieldToSafeStructure(field) {
  const type = (field.getAttribute("type") || field.tagName.toLowerCase()).toLowerCase();
  const name = field.getAttribute("name") || "";
  const id = field.getAttribute("id") || "";
  const sensitive = isSensitiveField(field);
  const placeholder = sensitive ? "" : getTrustedPlaceholder(field);

  return {
    tag: field.tagName.toLowerCase(),
    type,
    name,
    id,
    label: findFieldLabel(field),
    placeholder,
    required: Boolean(field.required),
    sensitive,
    selector: getUniqueSelector(field)
  };
}

function isCollectableFormField(field) {
  if (!isSafelyVisible(field)) return false;

  const tag = field.tagName.toLowerCase();
  const type = (field.getAttribute("type") || "").toLowerCase();
  if (tag === "input" && ["hidden", "button", "submit", "reset", "image"].includes(type)) return false;
  if (field.disabled) return false;
  if (field.getAttribute("aria-hidden") === "true") return false;

  return true;
}

function isSensitiveField(field) {
  const type = (field.getAttribute("type") || "").toLowerCase();
  const autocomplete = (field.getAttribute("autocomplete") || "").toLowerCase();
  const haystack = [
    field.getAttribute("name") || "",
    field.getAttribute("id") || "",
    field.getAttribute("aria-label") || "",
    autocomplete
  ].join(" ").toLowerCase();

  const sensitiveWords = ["password", "card", "cvv", "cvc", "otp", "ssn"];
  const cardAutocomplete = ["cc-number", "cc-csc", "cc-exp", "cc-exp-month", "cc-exp-year", "cc-name"];

  return type === "password" ||
    cardAutocomplete.some((word) => autocomplete.includes(word)) ||
    sensitiveWords.some((word) => haystack.includes(word));
}

function findFieldLabel(field) {
  if (field.id) {
    const directLabel = document.querySelector(`label[for="${cssEscape(field.id)}"]`);
    const directLabelText = getTrustedLabelText(directLabel);
    if (directLabelText) return directLabelText;
  }

  const ariaLabel = getTrustedFieldText(field, "aria-label");
  if (isLikelyPromotionalFieldText(ariaLabel)) return "";
  return ariaLabel;
}

function getTrustedPlaceholder(field) {
  const placeholder = getTrustedFieldText(field, "placeholder");
  if (isLikelyPromotionalFieldText(placeholder)) return "";
  return placeholder;
}

function getTrustedLabelText(labelElement) {
  if (!labelElement) return "";
  const labelText = cleanText(labelElement.innerText || labelElement.textContent);
  if (isLikelyPromotionalFieldText(labelText)) return "";
  return labelText;
}

function getTrustedFieldText(field, attributeName) {
  if (!field.hasAttribute(attributeName)) return "";
  return cleanText(field.getAttribute(attributeName) || "");
}

function isLikelyPromotionalFieldText(text) {
  return /s\s*rewards|shopeevip/i.test(text || "");
}

// ─── VISIBLE TEXT ──────────────────────────────────────────────────────────
function collectVisibleText() {
  const textNodes = [];
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent || !isSafelyVisible(parent)) return NodeFilter.FILTER_REJECT;
      if (["SCRIPT", "STYLE", "NOSCRIPT"].includes(parent.tagName)) return NodeFilter.FILTER_REJECT;
      const text = cleanText(node.nodeValue);
      return text ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });

  while (walker.nextNode() && textNodes.join(" ").length < 5200) {
    textNodes.push(cleanText(walker.currentNode.nodeValue));
  }

  return textNodes.join(" ").slice(0, 5000);
}

// ─── METADATA / SEO ───────────────────────────────────────────────────────
function collectMetadata() {
  const getMeta = (selector) => {
    const el = document.querySelector(selector);
    return cleanText(el?.getAttribute("content") || el?.getAttribute("href") || "");
  };

  return {
    lang: document.documentElement.getAttribute("lang") || "",
    description: getMeta("meta[name='description']"),
    keywords: getMeta("meta[name='keywords']"),
    ogTitle: getMeta("meta[property='og:title']"),
    ogDescription: getMeta("meta[property='og:description']"),
    ogImage: absolutizeUrl(getMeta("meta[property='og:image']")),
    twitterTitle: getMeta("meta[name='twitter:title']"),
    canonicalUrl: absolutizeUrl(getMeta("link[rel='canonical']")),
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight,
      devicePixelRatio: window.devicePixelRatio || 1,
      scrollY: Math.round(window.scrollY)
    }
  };
}

// ─── IMAGES ───────────────────────────────────────────────────────────────
function collectImages() {
  return Array.from(document.querySelectorAll("img"))
    .filter(isSafelyVisible)
    .slice(0, 50)
    .map((img) => {
      const alt = img.getAttribute("alt");
      const rect = img.getBoundingClientRect();
      return {
        src: absolutizeUrl(img.currentSrc || img.src || ""),
        alt: alt !== null ? alt : null,
        title: img.getAttribute("title") || "",
        ariaLabel: img.getAttribute("aria-label") || "",
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        hasMissingAlt: alt === null,
        hasUndefinedAlt: alt === "undefined" || alt === "null",
        selector: getUniqueSelector(img)
      };
    })
    .filter((img) => img.src);
}

// ─── PERFORMANCE ──────────────────────────────────────────────────────────
function collectPerformance() {
  try {
    const nav = performance.getEntriesByType("navigation")[0];
    if (!nav) return {};
    return {
      domContentLoadedMs: Math.round(nav.domContentLoadedEventEnd - nav.startTime),
      loadEventMs: Math.round(nav.loadEventEnd - nav.startTime),
      ttfbMs: Math.round(nav.responseStart - nav.requestStart),
      transferSizeKb: nav.transferSize ? Math.round(nav.transferSize / 1024) : null
    };
  } catch {
    return {};
  }
}

// ─── PRODUCTS ─────────────────────────────────────────────────────────────
function collectProducts() {
  const products = collectSchemaProducts();
  const seen = new Set(products.map((product) => `${product.name}|${product.price}`));

  [...collectLinkPriceProducts(), ...collectHeuristicProducts()].forEach((product) => {
    const key = `${product.name}|${product.price}`;
    if (!seen.has(key)) {
      seen.add(key);
      products.push(product);
    }
  });

  return products.slice(0, 50);
}

function collectSchemaProducts() {
  const productNodes = Array.from(document.querySelectorAll("[itemscope][itemtype*='Product'], [itemtype*='schema.org/Product']"));
  return productNodes
    .filter(isSafelyVisible)
    .map((node) => ({
      name: cleanText(readItemProp(node, "name") || node.querySelector("h1,h2,h3")?.innerText),
      price: cleanText(readItemProp(node, "price") || node.querySelector("[itemprop='price']")?.textContent),
      image: absolutizeUrl(readItemProp(node, "image") || node.querySelector("img")?.src),
      link: absolutizeUrl(node.querySelector("a[href]")?.href || location.href),
      selector: getUniqueSelector(node),
      source: "schema.org"
    }))
    .filter((product) => product.name || product.price);
}

function collectLinkPriceProducts() {
  const links = Array.from(document.querySelectorAll("a[href]"));
  return links
    .filter(isSafelyVisible)
    .map((link) => {
      const text = cleanText(link.innerText || link.textContent || "");
      const image = link.querySelector("img");
      const imageAlt = cleanText(image?.getAttribute("alt") || image?.getAttribute("title") || "");
      const price = extractPrice(text);
      if (!price) return null;

      return {
        name: guessProductNameFromLink(link, imageAlt, text, price),
        price,
        discount: extractDiscount(text),
        image: absolutizeUrl(image?.currentSrc || image?.src || ""),
        link: absolutizeUrl(link.href),
        selector: getUniqueSelector(link),
        source: "link-price"
      };
    })
    .filter((product) => product && (product.name || product.price))
    .slice(0, 30);
}

function collectHeuristicProducts() {
  const addToCartPattern = /thêm.*giỏ|add.*cart|buy now|mua ngay|đặt mua/i;
  const candidates = Array.from(document.querySelectorAll("article, li, .product, .product-card, [class*='product'], [data-product]"));

  return candidates
    .filter(isSafelyVisible)
    .map((node) => {
      const text = cleanText(node.innerText || node.textContent);
      const price = extractPrice(text);
      if (!price) return null;
      const buttonText = cleanText(Array.from(node.querySelectorAll("button, [role='button'], a"))
        .map((button) => button.innerText || button.textContent || button.getAttribute("aria-label") || "")
        .join(" "));
      if (!addToCartPattern.test(buttonText) && !node.matches("[data-product], [class*='product']")) return null;

      return {
        name: cleanText(node.querySelector("h1,h2,h3,[class*='name'],[class*='title']")?.innerText || text.split("\n")[0]),
        price,
        image: absolutizeUrl(node.querySelector("img")?.src || ""),
        link: absolutizeUrl(node.querySelector("a[href]")?.href || ""),
        selector: getUniqueSelector(node),
        source: "heuristic"
      };
    })
    .filter(Boolean);
}

// ─── CART SIGNALS ─────────────────────────────────────────────────────────
function collectCartSignals() {
  const cartPattern = /cart|basket|bag|giỏ hàng|gio hang|giỏ|checkout|thanh toán|thanh toan/i;
  return Array.from(document.querySelectorAll("a[href], button, [role='button'], [aria-label]"))
    .filter(isSafelyVisible)
    .filter((element) => cartPattern.test([
      element.innerText,
      element.textContent,
      element.getAttribute("href"),
      element.getAttribute("aria-label"),
      element.className,
      element.id
    ].join(" ")))
    .slice(0, 30)
    .map((element) => ({
      text: cleanText(element.innerText || element.textContent || element.getAttribute("aria-label")),
      href: element.href || "",
      itemCount: extractNearbyNumber(element),
      selector: getUniqueSelector(element)
    }));
}

// ─── HELPERS ──────────────────────────────────────────────────────────────
function readItemProp(root, propName) {
  const element = root.querySelector(`[itemprop='${propName}']`);
  if (!element) return "";
  return element.getAttribute("content") || element.getAttribute("src") || element.getAttribute("href") || element.textContent || "";
}

function extractNearbyNumber(element) {
  const text = cleanText(element.innerText || element.textContent || element.parentElement?.innerText || "");
  const match = text.match(/\b\d{1,3}\b/);
  return match ? Number(match[0]) : null;
}

function extractPrice(text) {
  const pricePattern = /(?:₫|đ|vnd)\s?\d[\d.,\s]*|(?:\d[\d.,\s]*)\s?(?:₫|đ|vnd)|(?:\$|€|£)\s?\d[\d.,\s]*|(?:\d[\d.,\s]*)\s?(?:\$|€|£)/i;
  return cleanText((String(text || "").match(pricePattern) || [""])[0]);
}

function extractDiscount(text) {
  const discountPattern = /-?\d{1,2}\s?%/;
  return cleanText((String(text || "").match(discountPattern) || [""])[0]);
}

function guessProductNameFromLink(link, imageAlt, text, price) {
  if (imageAlt) return imageAlt;

  const parts = text
    .split(/\n| {2,}/)
    .map(cleanText)
    .filter(Boolean)
    .filter((part) => part !== price && !extractPrice(part) && !/^-?\d{1,2}\s?%$/.test(part));

  return parts[0] || cleanText(link.getAttribute("title") || link.getAttribute("aria-label") || "");
}

function isVisible(element) {
  if (!element || !(element instanceof Element)) return false;
  if (isAdminUiElement(element)) return false;
  const style = window.getComputedStyle(element);
  if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function isSafelyVisible(element) {
  try {
    return isVisible(element);
  } catch (error) {
    console.warn("[AI Website Test Collector] Bo qua mot element vi loi khi kiem tra hien thi:", error);
    return false;
  }
}

function isAdminUiElement(element) {
  const adminPattern = /adminbar|admin-bar|wp-admin/i;
  return Boolean(element.closest("#wpadminbar")) ||
    hasAdminMarker(element, adminPattern);
}

function hasAdminMarker(element, adminPattern) {
  return adminPattern.test(element.id || "") ||
    Array.from(element.classList || []).some((className) => adminPattern.test(className));
}

function cleanText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function absolutizeUrl(value) {
  if (!value) return "";
  try {
    return new URL(value, location.href).href;
  } catch {
    return "";
  }
}

function cssEscape(value) {
  if (window.CSS?.escape) return window.CSS.escape(value);
  return String(value).replace(/["\\]/g, "\\$&");
}
