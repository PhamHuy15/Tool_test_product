function createElement({ id = "", classes = [], adminAncestor = false } = {}) {
  return {
    id,
    classList: classes,
    closest(selector) {
      if (selector === "#wpadminbar") {
        return adminAncestor ? { id: "wpadminbar" } : null;
      }
      return null;
    }
  };
}

function hasAdminMarker(element, adminPattern) {
  return adminPattern.test(element.id || "") ||
    Array.from(element.classList || []).some((className) => adminPattern.test(className));
}

function isAdminUiElement(element) {
  const adminPattern = /adminbar|admin-bar|wp-admin/i;
  return Boolean(element.closest("#wpadminbar")) ||
    hasAdminMarker(element, adminPattern);
}

const cases = [
  ["real content inside body.admin-bar must stay", createElement(), false],
  ["wp admin bar descendant must be excluded", createElement({ adminAncestor: true }), true],
  ["self id wpadminbar must be excluded", createElement({ id: "wpadminbar" }), true],
  ["self class custom-admin-bar must be excluded", createElement({ classes: ["custom-admin-bar"] }), true],
  ["self id wp-admin-link must be excluded", createElement({ id: "wp-admin-link" }), true]
];

let failed = 0;
cases.forEach(([name, element, expected]) => {
  const actual = isAdminUiElement(element);
  if (actual !== expected) {
    failed += 1;
    console.error(`Case failed: ${name}`, { expected, actual });
  }
});

if (failed > 0) {
  process.exitCode = 1;
} else {
  console.log("Admin filter tests passed.");
}
